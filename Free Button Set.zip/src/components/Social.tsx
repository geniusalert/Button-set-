import { FunctionComponent } from "react";
import "./Social.css";

const Social: FunctionComponent = () => {
  return (
    <div className="social">
      <div className="frame">
        <img
          className="red-heated-button1"
          alt=""
          src="/red-heated-button@2x.png"
        />
      </div>
      <div className="frame1">
        <div className="white-flat-button1">
          <div className="inner-plate1">
            <div className="engine1">Engine</div>
          </div>
        </div>
      </div>
      <img className="frame-icon" alt="" src="/frame@2x.png" />
      <div className="frame2">
        <div className="green-safety-button1">
          <div className="green-safety-button-item" />
          <div className="green1">
            <img className="base-blur-icon1" alt="" src="/base-blur@2x.png" />
            <img className="base-blur-icon1" alt="" src="/highlights@2x.png" />
            <div className="knob1">
              <div className="go1">GO</div>
              <img
                className="highlights-icon3"
                alt=""
                src="/highlights@2x.png"
              />
            </div>
          </div>
        </div>
      </div>
      <img className="red-mini-button1" alt="" src="/red-mini-button@2x.png" />
    </div>
  );
};

export default Social;
